const units = [
 {name:"Barbarian",type:"Troop",icon:"🪓",desc:"A fearless melee fighter who charges straight into the action."},
 {name:"Archer",type:"Troop",icon:"🏹",desc:"A ranged unit that attacks from a distance with precision."},
 {name:"Giant",type:"Troop",icon:"🛡️",desc:"A tough unit that prioritizes defensive buildings."},
 {name:"Wizard",type:"Troop",icon:"🧙",desc:"A powerful ranged attacker with splash damage."},
 {name:"Dragon",type:"Troop",icon:"🐉",desc:"A flying unit that breathes fire across the battlefield."},
 {name:"P.E.K.K.A",type:"Troop",icon:"⚔️",desc:"A heavily armored warrior with a mighty sword."},
 {name:"Barbarian King",type:"Hero",icon:"👑",desc:"A mighty hero who leads ground forces into battle."},
 {name:"Archer Queen",type:"Hero",icon:"🏹",desc:"A powerful ranged hero with a special ability."},
 {name:"Grand Warden",type:"Hero",icon:"🪄",desc:"A support hero who helps nearby troops."},
 {name:"Royal Champion",type:"Hero",icon:"🛡️",desc:"A skilled hero who targets defenses."},
 {name:"Lightning Spell",type:"Spell",icon:"⚡",desc:"Calls down lightning to damage a target area."},
 {name:"Healing Spell",type:"Spell",icon:"💚",desc:"Restores health to friendly troops in its area."},
 {name:"Unicorn",type:"Pet",icon:"🦄",desc:"A loyal companion that supports its assigned hero."},
 {name:"Mighty Yak",type:"Pet",icon:"🐂",desc:"A sturdy companion that helps clear nearby obstacles."}
];
let currentUser = null, registerMode = false;
const $ = s => document.querySelector(s);
function showModal(id){$("#"+id).classList.remove("hidden")}
function hideModal(id){$("#"+id).classList.add("hidden")}
function renderUnits(type="All"){
 $("#unit-grid").innerHTML=units.filter(u=>type==="All"||u.type===type).map(u=>`<article class="unit-card"><div class="unit-icon">${u.icon}</div><span class="tag">${u.type}</span><h3>${u.name}</h3><p>${u.desc}</p></article>`).join("");
}
function renderClans(clans){
 $("#clan-grid").innerHTML=clans.length?clans.map(c=>`<article class="clan-card"><div class="clan-top"><span class="clan-badge">🏰</span><span class="tag">LEVEL ${c.level}</span></div><h3>${escapeHtml(c.name)}</h3><p>${escapeHtml(c.description)}</p><div class="clan-meta"><span>${escapeHtml(c.tag)}</span><span>${c.members}/50 MEMBERS</span><span>TH ${c.required_th}+</span></div></article>`).join(""):"<p>No clans found. Try another search.</p>";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function api(url,options={}){const r=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});const d=await r.json();if(!r.ok)throw new Error(d.error||"Something went wrong.");return d;}
function updateUser(u){
 currentUser=u;$("#user-label").textContent=u?`CHIEF: ${u.username}`:"";$("#auth-open").classList.toggle("hidden",!!u);$("#logout").classList.toggle("hidden",!u);
}
async function load(){
 try{const {user}=await api("/api/me");updateUser(user);const clans=await api("/api/clans");renderClans(clans);$("#clan-count").textContent=clans.length;const stats=await api("/api/stats");$("#player-count").textContent=stats.players;}catch(e){console.error(e)}
}
$("#unit-filters").addEventListener("click",e=>{const b=e.target.closest("button[data-type]");if(!b)return;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderUnits(b.dataset.type);});
$("#clan-search").addEventListener("input",async e=>{try{renderClans(await api("/api/clans?q="+encodeURIComponent(e.target.value)));}catch(err){}});
$("#auth-open").onclick=()=>{registerMode=false;setAuthMode();showModal("auth-modal")};
$("#auth-switch").onclick=()=>{registerMode=!registerMode;setAuthMode()};
function setAuthMode(){$("#auth-title").textContent=registerMode?"CREATE ACCOUNT":"LOG IN";$("#auth-submit").textContent=registerMode?"Create account":"Log in";$("#auth-switch").innerHTML=registerMode?'Already have an account? <button type="button">Log in</button>':'New here? <button type="button">Create an account</button>';}
$("#auth-form").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);$("#auth-message").textContent="";try{const d=await api(registerMode?"/api/auth/register":"/api/auth/login",{method:"POST",body:JSON.stringify({username:f.get("username"),password:f.get("password")})});updateUser(d.user);hideModal("auth-modal");e.target.reset();}catch(err){$("#auth-message").textContent=err.message;}};
$("#logout").onclick=async()=>{await api("/api/auth/logout",{method:"POST",body:"{}"});updateUser(null)};
$("#profile-open").onclick=()=>{if(!currentUser){showModal("auth-modal");return;}const f=$("#profile-form");f.playerName.value=currentUser.playerName||currentUser.username;f.townHall.innerHTML=Array.from({length:18},(_,i)=>`<option value="${i+1}">Town Hall ${i+1}</option>`).join("");f.townHall.value=currentUser.townHall;showModal("profile-modal")};
$("#profile-form").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{const d=await api("/api/profile",{method:"PUT",body:JSON.stringify({playerName:f.get("playerName"),townHall:f.get("townHall")})});updateUser(d.user);$("#profile-message").textContent="Profile saved!";}catch(err){$("#profile-message").textContent=err.message;}};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>hideModal(b.dataset.close));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)hideModal(m.id)}));
renderUnits();load();
