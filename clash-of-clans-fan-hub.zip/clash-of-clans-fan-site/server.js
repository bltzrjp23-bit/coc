require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const db = new Database("clashhub.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 player_name TEXT NOT NULL DEFAULT '',
 town_hall INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clans (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 tag TEXT NOT NULL UNIQUE,
 level INTEGER NOT NULL,
 members INTEGER NOT NULL,
 required_th INTEGER NOT NULL,
 description TEXT NOT NULL
);
`);
const clanCount = db.prepare("SELECT COUNT(*) AS n FROM clans").get().n;
if (!clanCount) {
  const add = db.prepare("INSERT INTO clans(name,tag,level,members,required_th,description) VALUES(?,?,?,?,?,?)");
  [
    ["Barbarian Legends", "#2Q8J0P8L", 12, 42, 10, "Friendly clan focused on learning, teamwork and regular donations."],
    ["Dragon Riders", "#9P2YV8GC", 8, 36, 8, "War-minded community. Be active, respectful and ready to improve."],
    ["Goblin Academy", "#L0OT4FUN", 5, 24, 5, "A relaxed place for newer players to learn the basics."]
  ].forEach(x => add.run(...x));
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "clashhub.sid",
  secret: process.env.SESSION_SECRET || "dev-only-change-this-session-secret-please",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const safeUser = u => u && ({ id: u.id, username: u.username, playerName: u.player_name, townHall: u.town_hall });
const requireAuth = (req, res, next) => req.session.userId ? next() : res.status(401).json({ error: "Please log in first." });
const validName = s => typeof s === "string" && s.trim().length >= 3 && s.trim().length <= 20 && /^[a-zA-Z0-9_ ]+$/.test(s.trim());

app.get("/api/me", (req, res) => {
  const u = req.session.userId && db.prepare("SELECT id,username,player_name,town_hall FROM users WHERE id=?").get(req.session.userId);
  res.json({ user: safeUser(u) });
});
app.post("/api/auth/register", async (req, res) => {
  const { username, password } = req.body || {};
  if (!validName(username) || typeof password !== "string" || password.length < 8 || password.length > 72)
    return res.status(400).json({ error: "Use a 3–20 character username and a password of 8–72 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(username,password_hash,player_name) VALUES(?,?,?)").run(username.trim(), hash, username.trim());
    req.session.userId = result.lastInsertRowid;
    res.json({ user: safeUser(db.prepare("SELECT id,username,player_name,town_hall FROM users WHERE id=?").get(req.session.userId)) });
  } catch (e) {
    if (String(e.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "That username is already taken." });
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/auth/login", async (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare("SELECT * FROM users WHERE username=?").get(String(username || "").trim());
  if (!u || typeof password !== "string" || !(await bcrypt.compare(password, u.password_hash)))
    return res.status(401).json({ error: "Incorrect username or password." });
  req.session.userId = u.id;
  res.json({ user: safeUser(u) });
});
app.post("/api/auth/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.put("/api/profile", requireAuth, (req, res) => {
  const playerName = String(req.body.playerName || "").trim().slice(0, 20);
  const townHall = Number(req.body.townHall);
  if (!playerName || !Number.isInteger(townHall) || townHall < 1 || townHall > 18)
    return res.status(400).json({ error: "Enter a player name and Town Hall level from 1 to 18." });
  db.prepare("UPDATE users SET player_name=?,town_hall=? WHERE id=?").run(playerName, townHall, req.session.userId);
  res.json({ user: safeUser(db.prepare("SELECT id,username,player_name,town_hall FROM users WHERE id=?").get(req.session.userId)) });
});
app.get("/api/clans", (req, res) => {
  const q = String(req.query.q || "").slice(0, 60);
  res.json(db.prepare("SELECT id,name,tag,level,members,required_th,description FROM clans WHERE name LIKE ? OR tag LIKE ? ORDER BY level DESC")
    .all(`%${q}%`, `%${q}%`));
});
app.get("/api/stats", (req, res) => {
  res.json({ players: db.prepare("SELECT COUNT(*) n FROM users").get().n, clans: db.prepare("SELECT COUNT(*) n FROM clans").get().n });
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT) || 3000;
app.listen(port, () => console.log(`Clash of Clans Fan Hub running at http://localhost:${port}`));
