# Clash of Clans Fan Hub

An unofficial fan-made community website inspired by the world of Clash of Clans. It is not affiliated with, endorsed by, or operated by Supercell.

## Features
- Account registration, login and logout
- Secure password hashing and session cookies
- Player profile with editable player name and Town Hall level
- Troop, spell, hero and pet encyclopedia
- Village/base-building tips
- Clan directory with searchable sample clans
- Admin-ready structure kept intentionally simple

This starter site does not connect to Supercell accounts, request player passwords, sell accounts, or process payments.

## Run locally
1. Install Node.js 20 or newer.
2. Extract this project and open its folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`.
5. Run `npm start`.
6. Visit `http://localhost:3000`.

The SQLite database is created automatically as `clashhub.db`.

## Publish
Deploy to a Node.js host that supports persistent disk storage. Set `NODE_ENV=production`, `SESSION_SECRET`, and HTTPS. Use a persistent session store (such as Redis) for production rather than Express's default in-memory session store. Back up the SQLite database. Never commit `.env` or database files to GitHub.

## Branding and assets
The design uses original CSS artwork and text rather than Supercell game files. If you add game screenshots, logos, or other assets, follow Supercell's fan-content policy and applicable rights.
